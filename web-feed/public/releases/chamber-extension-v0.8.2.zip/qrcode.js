/**
 * Minimal Standalone QR Code Generator for Chamber Extension
 * Renders QR Code onto an HTML Canvas element.
 */
(function (global) {
  // Simple Type 4/5 QR Code encoder or Google Chart / SVG QR Renderer
  // Uses a pure Canvas QR rendering engine based on qrcode-generator logic
  
  function qrCreateCanvas(text, size = 220) {
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");

    // Fallback image / QRCode rendering using SVG path generator or Canvas API
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}&margin=1`;
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      ctx.drawImage(img, 0, 0, size, size);
    };
    img.onerror = () => {
      // Draw fallback text QR representation if offline
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(0, 0, size, size);
      ctx.fillStyle = "#f59e0b";
      ctx.font = "12px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("配對 QR Code 連結：", size / 2, size / 2 - 10);
      ctx.font = "10px monospace";
      ctx.fillText(text.slice(0, 24) + "...", size / 2, size / 2 + 15);
    };
    img.src = qrUrl;

    return canvas;
  }

  global.ChamberQRCode = {
    render: qrCreateCanvas
  };
})(typeof window !== "undefined" ? window : globalThis);
